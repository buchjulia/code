println("Abb. 7.11 (unkorr., w=4); Abb 7.12 (korr., w=4), Abb. 7.13 (korr., w=7)")
# Musterekennungsvariante
using Flux
using Plots
using IterTools: ncycle
using DelimitedFiles
using Statistics
using StatsBase
println("               ")
println("START")
#künstliche Daten
obs_no_corr=rand(9200).*0.5
# für Abb. 7.11. weglassen 16-19 
obs=obs_no_corr
# für Abb. 7.12 und 7.13: Periodizität=7
for i=1:9200
global obs
   if mod(i,7)==0 obs[i]=1+rand() end
end
min_obs=minimum(obs)
obs=obs.-min_obs
max_obs=maximum(obs)
println("MAXIMUM OBS= ", max_obs)
obs_norm=obs./max_obs
# window= 4 # für Abb. 7.11. und Abb. 7.12
window=7 # für Abb. 7.13
sample_size=(size(obs_norm,1))-window-1
println("#obs=", size(obs_norm,1), " sample_size= ", sample_size)
x_sample=rand(sample_size,window)
y_sample=rand(sample_size)
for i=1:sample_size
    x_sample[i,:]=obs_norm[i:i+window-1]
    y_sample[i]=obs_norm[i+window]
end
samples=sample_size  # redundant
train=5000
x=x_sample[1:train,:]
y=y_sample[1:train]

x_valid=x_sample[train+1:9000-window-1,:]
y_valid=y_sample[train+1:9000-window-1]
batch_size=4
train_loader = Flux.Data.DataLoader((x', y'), batchsize=batch_size,shuffle=true)  # shuffle=false
opt = ADAM(0.001, (0.9, 0.999))
m = Chain(Dense(window, 12,σ),Dense(12, 1,σ))
#m = Chain(Dense(window, 16,tanh),Dense(16, 1,tanh)) #! beachte Verbesserung von σ
#m = Chain(LSTM(window,8),LSTM(8,1))
loss(x, y) = Flux.mae(m(x), y)
ps = Flux.params(m)

num_epochs=100
#@time Flux.train!(loss, ps, ncycle(train_loader, num_epochs), opt,cb = () -> println("training")) # ??? throttle
@time Flux.train!(loss, ps, ncycle(train_loader, num_epochs),opt) # ??? throttle
println("FERTIG")
# Validieren über gleiceh Datenmenge

y_mod=rand(size(y_valid)[1])
loss_v=zeros(size(y_valid)[1])
loss_naive=zeros(size(y_valid)[1])
for i=1:size(y_valid)[1]
    y_mod[i]=m(x_valid[i,:])[1]
    loss_v[i]=abs(y_valid[i]-y_mod[i])
end

for i=2:size(y_valid)[1]
    loss_naive[i]=abs((y_valid[i]-y_valid[i-1]))
end
println("LOSS NAIVE =  ", mean(loss_naive))
println("LOSS= ",mean(loss_v))

plot([1:50],[y_valid[1:50] y_mod[1:50]],color=:black, linestyle=[:dash :solid],markershape=:auto,label=["valid" "model"],xaxis="Valid Schritt",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)

png("E:/BUCH/KAP_7/ABB_7/ABB_7_13")
