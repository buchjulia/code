println("Abb. 7.10 Outputwerte")
using Plots
function sigmoid(z)
       return 1.0 ./ (1.0 .+ exp.(-z))
       end
t0=time()
N1=2
N2=3
N3=2
W1=[0.15 0.2 0.35;0.25 0.3 0.35;0.15 0.2 0.35]
W2=[0.4 0.45 0.6 0.5;0.5 0.55 0.6 0.4]
X=[0.05 0.1]
Y=[0.3 0.5]
eta=0.5
RETT_E=[0]
RETT_OUT=[0 0]
iter=100
report=10
rett=1
#FORWARD
for i=1:iter
global W1,W2,rett,report,iter,N1,N2,N3,X,Y,RETT_E,RETT_OUT
A1=[X 1]
Z2=A1*W1'
A2=[sigmoid(Z2) 1]
Z3=A2*W2'
A3=sigmoid(Z3)
RETT_OUT=[RETT_OUT; A3]
Etotal=(Y-A3)*(Y-A3)'/N3
# BACKPROP
DELTA_OUT=-(Y-A3)
d3=DELTA_OUT.*A3.*(ones(length(A3))'-A3)
grad2=d3.*A2[1:N2+1]
W2_neu=W2[:,1:N2+1]-eta*grad2'
d2=(W2[:,1:N2]'*d3')'.*A2[1:N2]'.*(ones(length(A2[1:N2]))'-A2[1:N2]')
grad1=d2.*A1[1:N1+1]
W1_neu=W1[:,1:N1+1]-eta*grad1'
W1=W1_neu
W2=W2_neu
  if mod(i,report)==0
  println("iteration=",i)
  println("SOLL=",Y)
  println("IST=", A3)
  println("1.Etotal=",Etotal)
  println("W1=",W1)
  println("W2=",W2)
  E_total=DELTA_OUT*DELTA_OUT'/N3
  println("2.Etotal=",Etotal)
    RETT_E=[RETT_E E_total]
    println("RETT_E=", RETT_E)
    rett=rett+1
end
end
println("TIME=",time()-t0)
plot(RETT_OUT[2:iter,:], xlabel="Iteration",gridlinewidth=1,color=:black,linestyle=[:solid :dashdot],label=["Y[1] = 0.3 !" "Y[2] = 0.5 !"],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_10_2")
