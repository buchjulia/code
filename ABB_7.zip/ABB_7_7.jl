println("Abb. 7.7 Aktivierungsfunktionen sigmoid und tanh")
using Plots
function sigmoid(z)
       return 1.0 ./ (1.0 .+ exp.(-z))
       end
sig=zeros(100)
tan=zeros(100)
sigb=zeros(100)
tanb=zeros(100)
xi=zeros(100)
for i=1:100
      xi[i]=-3+0.06*i
      sig[i]=sigmoid(xi[i])
      tan[i]=tanh(xi[i])
      sigb[i]=sigmoid(xi[i]+0.5)
      tanb[i]=tanh(xi[i]+0.5)
end

plot(xi,[sig tan],color=:black,legend=:topleft,  gridlinewidth=1,linestyle=[:solid :dashdot],label=["sigmoid" "tanh"],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
vline!([0.0],color=:black, linestyle=:dot, label=:false)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_7")
