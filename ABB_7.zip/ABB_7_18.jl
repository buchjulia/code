println("Abb. 7.18 Prognose auf Stundenintervallen")
# Musterekennungsvariante
using Flux
using IterTools: ncycle
using DelimitedFiles
using Plots
using Statistics
println("               ")
println("START")
obs=readdlm("F:/BUCH/Github_Zip/KAP_7/minute_load.csv");
obs=obs[:,2]
N=size(obs)[1]
println("++UEBERSICHT DATEN ++  N= ",N)
# Normierung
obs=obs[1:N]
min_obs=minimum(obs)
obs=obs.-min_obs
max_obs=maximum(obs)
println("MAXIMUM OBS= ", max_obs)
obs_norm=obs./max_obs
# Stundenlasten := Summe 60 Minutenlasten
N_stunden=Int16.(floor(N/60))
println("Stunden= ",N_stunden)
obs_h=rand(N_stunden)
for i=1:N_stunden
    obs_h[i]=sum(obs_norm[(i-1)*60+1:i*60])
end
obs_h=obs_h./maximum(obs_h)
window=24
sample_size=(size(obs_h,1))-window-1
println("#obs=", size(obs_h,1), " sample_size= ", sample_size)
x_sample=rand(sample_size,window)
y_sample=rand(sample_size)
for i=1+window:sample_size
    x_sample[i,:]=obs_h[i-window+1:i]
    y_sample[i]=obs_h[i+1]

    x_sample[i,1]=(mod(floor(i/24),7)+1)/7    #Tag
    x_sample[i,2]=(mod(floor(i),24)+1)/24    # Stunde
end
samples=sample_size  # redundant
train=1000
x=x_sample[1:train,:]
y=y_sample[1:train]

x_valid=x_sample[train+1:train+450,:]
y_valid=y_sample[train+1:train+450]
batch_size=4
train_loader = Flux.Data.DataLoader((x', y'), batchsize=batch_size,shuffle=true)  # shuffle=false
opt = ADAM(0.001, (0.9, 0.999))
m =Chain(Dense(window,100,σ),Dense(100,50,σ),Dense(50,25,σ),Dense(25,1,σ))
#m = Chain(Dense(window, 16,tanh),Dense(16, 1,tanh)) #! beachte Verbesserung von σ
#m = Chain(LSTM(window,8),LSTM(8,1))
#m = Chain(LSTM(window,150),LSTM(150,10),Dense(10,1,σ))
loss(x, y) = Flux.mae(m(x), y)
ps = Flux.params(m)
num_epochs=100
#@time Flux.train!(loss, ps, ncycle(train_loader, num_epochs), opt,cb = () -> println("training")) # ??? throttle
t1=time()
Flux.train!(loss, ps, ncycle(train_loader, num_epochs),opt)
println("time= ",time()-t1)
println("FERTIG")
# Validieren
y_mod=rand(size(y_valid)[1])
loss_v=zeros(size(y_valid)[1])
loss_naive=zeros(size(y_valid)[1])
for i=1:size(y_valid)[1]
    y_mod[i]=m(x_valid[i,:])[1]
    loss_v[i]=abs(y_valid[i]-y_mod[i])
end
for i=2:size(y_valid)[1]
    loss_naive[i]=abs((y_valid[i]-y_valid[i-1]))
end

println("LOSS NAIVE =  ", mean(loss_naive))
println("LOSS= ",mean(loss_v))
plot([1:100],[y_valid[1:100] y_mod[1:100]],color=:black, linestyle=[:dash :solid],markershape=[:circle :cross],markersize=3.0,label=["valid" "model"],xaxis="Valid Schritt",legendfontsize=12, dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_18")
