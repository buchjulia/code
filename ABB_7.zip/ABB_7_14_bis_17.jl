println("Abb. 7.14 66 Tage-Werte; Abb. 7.15 Ausschnitt, Abb. 7.16 Hochlastbereich; Abb. 7.17 AKF Hochlastbereich")
using Plots
using DelimitedFiles
using Statistics
using StatsBase
obs=readdlm("F:/BUCH/Github_Zip/KAP_7/minute_load.csv");
obs=obs[:,2]
obs=obs./maximum(obs)
N=size(obs)[1]
scatter(obs,color=:black,markershape=:circle, markersize = 0.8,label="Messwerte",xaxis="Nr. Messwert",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12, dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_14")

scatter([1200:2400],obs[1100:2400],color=:black,markershape=:circle, markersize = 1.0,label="Messwerte",xaxis="Nr. Messwert",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=10, dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_15")

scatter([2100:2400],obs[2100:2400],color=:black,markershape=:circle, markersize = 1.5,label="Messwerte",xaxis="Nr. Messwert",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=10, dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_16")

plot(0:9,autocor(obs[2100:2400],demean=true)[1:10],color=:black,markershape=:circle, markersize = 3.0,label="AKF(k)",linestyle=:dash,xaxis="k",yaxis="AKF(k)",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12, dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_17")
