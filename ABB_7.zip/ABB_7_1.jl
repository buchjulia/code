println("Abb. 7.1 Nichtstationäre Zeitreihe")
using Flux
using Plots
using IterTools: ncycle
using DelimitedFiles
using Statistics
println("               ")
println("START")
obs=readdlm("F:/BUCH/Github_Zip/KAP_7/youtube_rtt.txt");
println("obs1= ",obs[1])
println("++UEBERSICHT DATEN ++++")
N=size(obs)[1]

println("Messintervall = 1s, Anzahl der Messungen = ",N)
Stunden=floor(N/3600)
Minuten= floor((N-Stunden*3600)/60)
Sekunden=N-Stunden*3600-Minuten*60
println(" h min sec = ",Stunden," ",Minuten," ", Sekunden)
println(" Mittelwert nicht normiert = ", mean(obs))
# Normierung
#optional Datenmanipolation: periodisch
obs=obs[61600:71800]
min_obs=minimum(obs)
obs=obs.-min_obs
max_obs=maximum(obs)
obs_norm=obs./max_obs # evtl. noch um 0 verteilen
#Outlier Reduction

window=4
sample_size=(size(obs_norm,1))-window-1
println("#obs=", size(obs_norm,1), " sample_size= ", sample_size)
x_sample=rand(sample_size,window)
y_sample=rand(sample_size)
for i=1:sample_size
    x_sample[i,:]=obs_norm[i:i+window-1]
    y_sample[i]=obs_norm[i+window]
end
samples=sample_size  # redundant
#x=x_sample[71600:71800,:]
#y=y_sample[71600:71800]
x=x_sample
y=y_sample
opt = ADAM(0.01, (0.9, 0.999))
m = Chain(Dense(window, 120,σ), Dense(120, 1,σ))
#m=Chain(LSTM(window,8),LSTM(8,1))
loss(x, y) = Flux.mse(m(x), y)
ps = Flux.params(m)
println("FERTIG")
# Validieren über gleiceh Datenmenge
losses=zeros(size(y)[1])

y_mod=zeros(size(y)[1])
for i=1:size(y)[1]
Flux.train!(loss, ps, [(x[i,:],y[i])], opt)
Flux.train!(loss, ps, [(x[i,:],y[i])], opt)
y_mod[i]=m(x[i,:])[1]
losses[i]=loss(x[i,:],y[i]) # hier mit mod nur jeden 100-ten
end
println("LOSS = ", mean(losses))

#println("y_mod= = ", y_mod)
#println("losses = ", losses)
#plot([y[10000:10199-window] y_mod[10000:10199-window]],color=:black;xaxis="Folge Messwerte",yaxis="rtt normiert",linestyle=[:solid :dash], label=["valid" "model"], fontfamily="Arial",linewidth=0.7,xguidefontsize=14,yguidefontsize=14,tickfontsizes=10,legendfontsize=10,dpi=600)
# Validierung
plot(y[10000:10199-window],color=:black;xaxis="Folge Messwerte",yaxis="rtt normiert",linestyle=:solid, markershape=:circle, markersize = 2,label="rtt", fontfamily="Arial",linewidth=0.7,xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
png("E:/BUCH/KAP_7/ABB_7/ABB_7_1")
