println("Abb. 6.8 Ausgangsgraph, Abb. 6.9 MST")
using Graphs, GraphRecipes
using SimpleWeightedGraphs
using Plots
const n = 6

const A=[0 4 2 5 0 0;  # Topologie erlaubt verschiedene Routen im Viereck 4 - 6 -1 - 3
      4 0 4 0 3 0;
      2 4 0 4 3 5;
      5 0 4 0 0 6;
      0 3 3 0 0 4;
      0 0 5 6 4 0]

edgelabel_dict=A

graphplot(A,
          markersize = 0.2,
          node_weights = fill(2,n),
          # markercolor = range(colorant"darkgrey", stop=colorant"grey", length=n),
          markercolor = :grey,
          names = 1:n,
          fontsize = 10,
          linecolor = :darkgrey,
          nodestyle=:circle,
          curves=false,
          nodeshape=:circle,
          edgelabel=edgelabel_dict,
          dpi=600,
          fontfamily="Arial"
          )
png("E:/BUCH/KAP_6/ABB_6/ABB_6_8")



g=SimpleWeightedGraph(A)
          K_MST=kruskal_mst(g)
          println("_MST= ",K_MST)
          g_mst = SimpleWeightedGraph(size(g)[1]) #Create a new graph
          for ew in kruskal_mst(g)
             add_edge!(g_mst,ew.src,ew.dst,ew.weight)
          end

          graphplot(g_mst,
                    markersize = 0.2,
                    node_weights = fill(2,n),
                    # markercolor = range(colorant"darkgrey", stop=colorant"grey", length=n),
                    markercolor = :grey,
                    names = 1:n,
                    fontsize = 10,
                    linecolor = :darkgrey,
                    nodestyle=:circle,
                    curves=false,
                    nodeshape=:circle,
                    edgelabel=edgelabel_dict,
                    dpi=600,
                    fontfamily="Arial"
                    )
png("E:/BUCH/KAP_6/ABB_6/ABB_6_9")
