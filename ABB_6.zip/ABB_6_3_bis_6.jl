println("Abb. 6.3, 6.4 ohne Berg/Häuser: alpha=1.0; Abb. 6.5, 6.6 mit Berg/Häuser: alpha=2.0 ") 
using Plots

# Funktion zur Reduktion der Anzahl APs (BS)
function F_A_reduziert(A_ID)        # Ermittlung der F-Werte für A\AP*
    global M,M_ID,m,PL                   # Verwendung der pathlloss Werte
        k=size(A_ID,1)
        best_AP_ID=Int16.(zeros(m))    # für jeden Messpunkt bester Acceesspunkt finden
        for i=1:m
        best_AP_ID[i]=findmin(PL[M_ID[i],A_ID[:]])[2]
        end
        pl=zeros(m)     # für pathloss nach Formel f1
        pl_max=15.0
        mue=0.5
        for i=1:m       # f1 formel berechnen für jeden Messpunkt Pathloss zu bestem Accesspunkt
            pl[i]=PL[M_ID[i],A_ID[best_AP_ID[i]]]+mue*maximum([0,PL[M_ID[i],A_ID[best_AP_ID[i]]]-pl_max])
        end
        f1=sum(pl)/m    # Mittelwert für f1: Formel f1 fertig berechnet
        f2=maximum(pl)  # f2 berechnen: welcher Messpunkt aht schlechtesten Empfang
        kappa=0.5       # Wichgtungsfaktor f1, f2 für finale F-Formel
        F=kappa*f1+(1-kappa)*f2
        return F        # F(AP\AP*)
    end

println("   ")
println(" PROGRAMM-START GRID AP REDUKTION ")

#Initialisierung
# wir nehmen geogr. Entfernungen von Basestations zu "Referenz-Endsystemen" MPs
# X-Y Koordinaten der MPs
M=[3 3 7 9 1 9 6;3 8 2 8 5 3 6]'    # Mess-/Referenzpunkte [X,Y]
A=[3 8 6 7 3;6 5 4 8 4]'
m=size(M,1)            # mögliche Accesspunkte
M_ID=Int16.(zeros(m))
for i=1:m M_ID[i]=i end
k=size(A,1)
A_ID=Int16.(zeros(k))           # mögliche Accesspunkte
for i=1:k A_ID[i]=i end                      # Zähler d. noch übrigen APs
PL=zeros(m,k)
alpha=1.0                           # bei PL-Modellberechnug: Wichtungsfaktor Dämpfung
for i=1:m
    for j=1:k
        PL[i,j]=((M[i,1]-A[j,1])^2+(M[i,2]-A[j,2])^2)*alpha # quadr. Entf.  für Friis-Formel
    end
end
# alpha für Abb. 6.5, 6.6 Berge/Häuser anders: alpha händisch editieren
alpha_haus=2.0
m_haus=2    # ID MP Haus
k_haus=1    # ID AP Haus
println("PL Haus vorher = ", PL[m_haus,k_haus])
PL[m_haus,k_haus]=PL[m_haus,k_haus]*alpha_haus
println("PL Haus neu = ", PL[m_haus,k_haus])

alpha_berg=2.0
m_berg=3  # ID MP Berg
k_berg=3  # ID  AP Berg
PL[m_berg,k_berg]=PL[m_berg,k_berg]*alpha_berg

# jetzt simulieren wir die messbasierte Eingabe
println(" Optional Eingabe der Messwerte (ohne Berg, Haus) ")
println("# Pathloss = ")
for i=1:m
    println("#",round.(PL[i,:],digits=3))
end
K=1                        # wir lassen den Algorithmus bis k=K=1 laufen
F_trace=[]
anim = @animate while k>K                         # und geben auch die Zwischenergebnisse k>1 aus
      global k,A_ID,A,F_trace
    F_red=zeros(k)
    for i=1:k
        F_red[i]=F_A_reduziert(A_ID[1:end .!= i])    # A*:= A[1:end .!= i,:]
    end
k=k-1
skip=findmin(F_red)     # Accesspoint, dessen Wegnahmen min(F_red) ergab
A_ID=A_ID[1:end .!= skip[2]]       # Entfernen dieses Accesspoints
#println("ERGEBNIS kreduziert = ",k, "  A_ID reduziert=", A_ID, "  A= ",  A[A_ID,:])  # Ausgabe Ergebnisse bis k=K erreicht
println("F= ",skip[1])
F_trace=[skip[1];F_trace]
println("F_trace= ", F_trace)

A=A[1:end .!= skip[2],:]
println(" A_ID " , A_ID)

scatter(A[:,1]',A[:,2]', legend=false,ylim=(0,10), xlim=(0,10),color=:white,markerstrokecolors=:lightgrey,markershape = :circle,markersize = 100,title="Access Punkte: ◉, Messpunkte: ◻",xguidefontsize=14,yguidefontsize=14,tickfontsizes=10,legendfontsize=12)
scatter!(A[:,1]',A[:,2]', legend=false,ylim=(0,10), xlim=(0,10),color=:white,markerstrokecolors=:grey,markershape = :circle,markersize = 60)
scatter!(A[:,1]',A[:,2]', legend=false,ylim=(0,10), xlim=(0,10),color=:white,markerstrokecolors=:black,markershape = :circle,markersize = 20)
scatter!(A[:,1]',A[:,2]', legend=false,ylim=(0,10), xlim=(0,10),color=:black,markerstrokecolors=:black,markersize = 10)
#scatter!(X,GRID_VIS, legend=false,ylim=(0,10), xlim=(0,10),color=:white,markershape =:circle,markersize = 15)
scatter!(M[:,1]',M[:,2]', legend=false,ylim=(0,10), xlim=(0,10),color=:white,markershape = :rect, title="Access Punkte: ◉, Messpunkte: ◻",markersize = 10)

k_plot=2 # Diagramm ablegen für k=2
if k==k_plot
png("E:/BUCH/KAP_6/ABB_6/ABB_6_6")
end
end
gif(anim, "E:/BUCH/KAP_6/ABB_6/ABB_6_3_ANIMATION.gif", fps=0.5)
plot(F_trace[1:size(F_trace)[1]],linetype=:bar,color=:grey,linestyle=:solid,bar_width=0.2,xaxis="k",yaxis="F(k)",label="Verluste F(k)",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
png("E:/BUCH/KAP_6/ABB_6/ABB_6_5")
