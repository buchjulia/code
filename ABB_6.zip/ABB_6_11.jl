println("Abb. 6.11 optimale Kosten bei h=1.4")
# Berechnung Steiner_Tree
a=1
b=2
G_S=zeros(20)
G_K=zeros(20)
H=zeros(20)
for i=1:20
    h=i*0.1
    H[i]=h
    G_K[i]=2*a+b
    k=sqrt((a/2)^2+((b-h)/2)^2)
    G_S[i]=4*k+h
end
using Plots
plot(H,[G_K G_S],xaxis="h",yaxis="Kosten",label=["Kruskal" "Steiner"],color=:black,linestyle=[:solid :dashdot],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
png("E:/BUCH/KAP_6/ABB_6/ABB_6_11")
