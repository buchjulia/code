println("Abb. 6.13 Ergebnis SPF Berechnung für R1")
using Graphs, SimpleWeightedGraphs
g = SimpleWeightedGraph(3)  # or use `SimpleWeightedDiGraph` for directed graphs
add_edge!(g, 1, 2, 0.5)
add_edge!(g, 2, 3, 0.8)
add_edge!(g, 1, 3, 2.0)
w1=get_weight(g, 1, 2)
println("w1= ", w1)
p=enumerate_paths(dijkstra_shortest_paths(g, 1), 3)
println("p= ",p)
AD_M=[0 2 5 1 0 0;  # Topologie erlaubt verschiedene Routen im Viereck 4 - 6 -1 - 3
      2 0 3 2 0 0;
      5 3 0 3 1 6;
      1 2 3 0 1 0;
      0 0 1 1 0 4;
      0 0 6 0 4 0]
g_D=SimpleWeightedGraph(AD_M)
for i=2:6
p_D=enumerate_paths(dijkstra_shortest_paths(g_D, 1), i)
println("p_D= ",p_D)
end
