println("Abb. 6.1  Signalstreuungen für SNR=17, SNR=14")
using SignalAnalysis, SignalAnalysis.Units
using Plots
using DigitalComm
# --- Parameter
snr		  = 17;
#snr      	=   14;
mcs		  = 16;
nbBits	  = 1024* Int(log2(mcs));
# --- Generierung Bitfolge
bitSeq	  = genBitSequence(nbBits);
# --- QPSK mapping
qamSeq	  = bitMappingQAM(mcs,bitSeq);
# ----------------------------------------------------
# --- Übertragungskanal
# ----------------------------------------------------
#  --- Additive White Gaussian Noise AWGN
# Theoretical power 1 (normalized constellation)
qamNoise,  = addNoise(qamSeq,snr,1);
# ----------------------------------------------------
# --- Rx Stage: SRRC
# ----------------------------------------------------
# --- Binary demapper
bitDec	= bitDemappingQAM(mcs,qamNoise);
# --- BER measure
ber	  = sum(xor.(bitDec,bitSeq)) /length(bitSeq);
# --- Display constellation
plt	  = scatter(real(qamNoise),imag(qamNoise),label="Gestört",color=:lightgrey,fontfamily="Arial",xguidefontsize=10,yguidefontsize=10,tickfontsizes=10,legendfontsize=6,dpi=600);
scatter!(plt,real(qamSeq),imag(qamSeq),title="SNR=14, mcs=16",titlefontsize=11,label="Ideal",markersize=5,color=:black,fontfamily="Arial",xguidefontsize=10,yguidefontsize=10,tickfontsizes=10,legendfontsize=8,dpi=600);
xlabel!("Real part");
ylabel!("Imag part");
display(plt);
png("E:/BUCH/KAP_6/ABB_6/ABB_6_1_b")
