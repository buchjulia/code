println("Abb. 5.16 Abweisungsrate für MBR")
using Plots
using Distributions
using StatsBase
#SLA: p1_rej<4%  p2_reject<6%

# 2 Bedienerpools je s1, s2=S-s1 Bediener
mean_trace=zeros(15)
la_trace=zeros(15)
for iter=1:15
    global mean_trace,la_trace
    la2=0.3*iter
    la_trace[iter]=iter

S=100
s2=50
SimT=1000000
#la2=3.3  # expo
t2=25.0   # Dau1er 2: expo oder detreminitisch,...
# haben 4 Ereignisquellen ta1, ta2, td1, td2
ta2=0.0
#td müssen in Belegungsvektor verwaltet werden
belegt_2=0
dv2=Float64[2*SimT] # damit kan der Vektor s+1 lang werden

moni_ind=0  # Zeitpunkte für moni
d_moni=3000  # moni Intervall
moni=d_moni  # Zeitpunkt für Statistik der n-Mittelwerte N1, N24
n2_rej=0
n2=0
trace_p2=zeros(Int32.(ceil(SimT/moni)))
#trace_p2=zeros(Int32(SimT/d_moni))
#trace_p1=zeros(Int32(SimT/d_moni))

t=0.0
                println("   ")
while t<SimT
                # events aktuell

                #println("ta1= ",ta1)
events=[ta2,minimum(dv2), moni]
#println("events= ", events)
now=findmin(events)
ev_type=now[2]
ev_time=now[1]
#println("now= ", ev_type," ",ev_time, " belegt_1= ",belegt_1)
if ev_type==1
        # Ankunft 2
    n2=n2+1
    t=ta2
    if belegt_2<s2
                # Eintrag in Vektor
                belegt_2=belegt_2+1
                r_neu=1+(s2-belegt_2)/belegt_2
                r_alt=1+(s2-belegt_2-1)/(belegt_2-1)
                t2_r=t2/r_neu+t
                push!(dv2,t2_r)
                #push!(dv2,t+rand(Exponential(t2)))


              dv2.=(dv2.-t).*(r_alt/r_neu).+t


    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n2_rej=n2_rej+1
    end
    ta2=t+rand(Exponential(1/la2))
end
if ev_type==2
    # Abgang 2
    # Abgang 1
    ab2=findmin(dv2)
    t=ab2[1]
    deleteat!(dv2,ab2[2])
    belegt_2=belegt_2-1
    r_neu=1+(s2-belegt_2)/belegt_2
    r_alt=1+(s2-belegt_2+1)/(belegt_2+1)

    dv2.=(dv2.-t).*(r_alt/r_neu).+t


end
if ev_type==3
    t=moni
moni_ind=moni_ind+1
#println("MONI: n1= ",n1, "   n1_reject=  ", n1_rej)
trace_p2[moni_ind]=n2_rej/n2
#s1,s2=heuristic(n1_rej/n1,n2_rej/n2,s1,s2)
n2=0
n2_rej=0
moni=t+d_moni
end
end
#plot([trace_p1 trace_p2], linetype=[:steppre :steppre])
println("Ergebnis:")
println("rho 2=   p2_rej=    ", la2*t2/s2 , "    ",mean(trace_p2))
#mean_trace=fill(mean(trace_p2),100)
#plot!([trace_p2[1:100]  mean_trace],label="p2_reject", linestyle=:solid, color=:black,yaxis="p_reject",xaxis="Mess-Intervall ",dpi=600,fontfamily="Arial",tickfontsizes=10)
#png("E:/My_Drive/BUCH_3/KAP_5_ACCESS_CORE/ABB_5/ABB_5_11")

mean_trace[iter]=mean(trace_p2)
end
println("ERGEBNIS=  ",mean_trace)
#plot!(la_trace[6:12].*0.3, mean_trace[6:12],label="t2=20", linestyle=:dashdot, color=:black,yaxis="p2_reject",xaxis="la2 ",dpi=600,fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12)
plot!(la_trace[6:12].*0.3, [mean_trace[6:12] fill(0.055,7)],label=["t2=25" "ohne MBR"], linestyle=[:dashdotdot :solid], color=:black,yaxis="p2_reject",xaxis="la2 ",dpi=600,fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12)

png("E:/BUCH/KAP_5/ABB_5/ABB_5_16")
