println("Abb. 5.14 Erfüllung der p_reject SLA")
#jetzt soll das System lernrn, welche Entscheidungen gut sind
using Plots
using Distributions
#using StatsBase
#SLA: p1_rej<4%  p2_reject<6%

# 2 Bedienerpools je s1, s2=S-s1 Bediener
S=100
s1=60
s2=S-s1
SimT=300000
d_moni=300  # moni Intervall
la1=3.0  # expo
t1=15.0  # Dauer 1: expo oder detreminitisch,...
la2=3.0  # expo
t2=15.0   # Dau1er 2: expo oder detreminitisch,...
# haben 4 Ereignisquellen ta1, ta2, td1, td2
ta1=0.0
ta2=0.0
#td müssen in Belegungsvektor verwaltet werden
dv1=Float64[2*SimT]
belegt_1=0
belegt_2=0
dv2=Float64[2*SimT] # damit kan der Vektor s+1 lang werden

moni_ind=0  # Zeitpunkte für moni
moni=d_moni  # Zeitpunkt für Statistik der n-Mittelwerte N1, N24
n1_rej=0
n2_rej=0
p1_rej=0.0
p2_rej=0.0
n1=0
n2=0

# für Q-Learn
Q=zeros(4,3)
action=[-1;0;1]
Ziel1=0.06
Ziel2=0.04
#delta_old=0
delta_new=0
# R = sum(KPI)
state_i=1  # wird für KPI genommen
action_i=1
N=Int32.(floor(SimT/moni))
println("N= ",N)
trace_p2=[]
trace_p1=[]
trace_KPI=[]
#trace_p2=zeros(Int32(SimT/d_moni))
#trace_p1=zeros(Int32(SimT/d_moni))

t=0.0
                #println("   ")
                #println("ta1111= ",ta1)
while t<SimT
    global t,ta1,ta2,s1,s2,moni,dv1,dv2,n1,n2,n1_rej,n2_rej,trace_p1,trace_p2,moni_ind,belegt_1,belegt_2, p1_rej, p2_rej
                # events aktuell
   global Q,state_i,Q,action_i, delta_old, delta_new
                #println("ta1= ",ta1)
events=[ta1,ta2, minimum(dv1), minimum(dv2), moni]
#println("events= ", events)
now=findmin(events)
ev_type=now[2]
ev_time=now[1]
t=ev_time
#println("now= ", ev_type," ",ev_time, " belegt_1= ",belegt_1)
if ev_type==1
    # Ankunft 1
    n1=n1+1
    #t=ta1
    if belegt_1<s1
                # Eintrag in Vektor
                #push!(dv1,t+t1)
                push!(dv1,t+rand(Exponential(t1)))
                belegt_1=belegt_1+1
    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n1_rej=n1_rej+1
    end
    ta1=t+rand(Exponential(1/la1))
    #ta1=t+1/la1
                    #println("ta222= ",ta1)
end
if ev_type==2
        # Ankunft 2
    n2=n2+1
    #t=ta2
    if belegt_2<s2
                # Eintrag in Vektor
                #push!(dv2,t+t2)
                push!(dv2,t+rand(Exponential(t2)))
                belegt_2=belegt_2+1
    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n2_rej=n2_rej+1
    end
    ta2=t+rand(Exponential(1/la2))
end
if ev_type==3
    # Abgang 1
    ab1=findmin(dv1)
    #t=ab1[1]
    deleteat!(dv1,ab1[2])
    belegt_1=belegt_1-1
end
if ev_type==4
    # Abgang 2
    # Abgang 1
    ab2=findmin(dv2)
    #t=ab2[1]
    deleteat!(dv2,ab2[2])
    belegt_2=belegt_2-1
end
if ev_type==5
    #t=moni
moni_ind=moni_ind+1
p1_rej=n1_rej/n1
p2_rej=n2_rej/n2
delta_new=abs(p1_rej-Ziel1)/Ziel1+abs(p2_rej-Ziel2)/Ziel2
R=1-delta_new
trace_p1=[trace_p1; p1_rej]
trace_p2=[trace_p2; p2_rej]
# neuer Zustand state_j
KPI1=0
KPI2=0
if p1_rej<Ziel1 KPI1=1 end  # funktioniert für 0.04, 0.06
if p2_rej<Ziel2 KPI2=1 end
if KPI1+KPI2==0 state_j=1 end
if KPI1+KPI2==2 state_j=4 end
if KPI1==0 && KPI2==1 state_j=2 end
if KPI1==1 && KPI2==0 state_j=3 end
# Ermittlung Potential nächste action im Zustand state_j
max_Q_next=findmax(Q[state_j,:])[1]
alpha=1000/(2000+moni_ind)
#gamma=0.9 # Wichtung Potential actions aus neuem state_j für Q(letzter Schritt)
gamma=0.1
Q[state_i,action_i]=(1-alpha)*Q[state_i,action_i]+alpha*(R+gamma*max_Q_next)
#Auswahl nächste Action
G1=1000
G2=2000
p_greedy=1-G1/(G2+moni_ind)   # zu Beginn wird viel exploriert: p_greedy=0.5
greedy_action=findmax(Q[state_j,:])[2]
if rand()>p_greedy
    action_j=rand(deleteat!([1;2;3],greedy_action)) # Auswahl non_greedy action
else
    action_j=greedy_action
end
s1=s1+action[action_j]
if s1>S-1 s1=S-1 end   #am Rand s=1 und s=S eingrenzen
if s1<1 s1=1 end
# s1=50 # für Bestimmung des Optimierungsbereiches für Lasten
s2=S-s1
if moni_ind>N-10
    println("moni_ind= ",moni_ind, "[s1 s2]= ",[s1 s2])
end
action_i=action_j
state_i=state_j
delta_old=delta_new
moni=t+d_moni
n1=0
n2=0
n1_rej=0
n2_rej=0
end
end
println("Ergebnis:")
#println("rho 1=   p1_rej=    ", la1*t1/s1 , "    ", mean(trace_p1[N-10:N]))
#println("rho 2=   p2_rej=    ", la2*t2/s2 , "    ",mean(trace_p2[N-10:N]))
#plot(trace_p1, linetype=:steppre,label="p1_reject $Ziel1 !",linestyle=:solid, color=:black,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=14,yguidefontsize=14,tickfontsizes=10,legendfontsize=12,dpi=600)
#plot!(-trace_p2, linetype=:steppre,label="(-1)*p2_reject $Ziel2 !",linestyle=:dash, color=:black,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=14,yguidefontsize=14,tickfontsizes=10,legendfontsize=12,dpi=600)
# geglättet
window=5
glatt_p1=zeros(N-window-1)
glatt_p2=zeros(N-window-1)
for i=1:N-window-1
glatt_p1[i]=mean(trace_p1[1:i+window])
glatt_p2[i]=mean(trace_p2[1:i+window])
end
n_glatt=length(glatt_p1)
println()
#plot(glatt_p1, linetype=:steppre,label="p1_reject $Ziel1 !",linestyle=:solid, color=:black,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
#plot!(glatt_p2, linetype=:steppre,label="p2_reject $Ziel2 !",linestyle=:dash, color=:black,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)

plot(glatt_p1[1:n_glatt-2], linetype=:steppre,label=:false,linestyle=:solid, color=:red,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
plot!(glatt_p2[1:n_glatt-2], linetype=:steppre,label=:false,linestyle=:dash, color=:red,yaxis="p_reject",xaxis="Mess-Intervall ",fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)

png("E:/BUCH/KAP_5/ABB_5/ABB_5_14")
