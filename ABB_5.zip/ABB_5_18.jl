println("Abb. 5.18 Verkürzung der Belegungszeiten von File-Transfer mit MBR-Scheduling")
using Plots
using Distributions
using StatsBase
#SLA: p1_rej<4%  p2_reject<6%

# 2 Bedienerpools je s1, s2=S-s1 Bediener
S=100
s2=50
SimT=100000
la2=3.0  # expo
t2=15.0   # Dau1er 2: expo oder detreminitisch,...
# haben 4 Ereignisquellen ta1, ta2, td1, td2
ta2=0.0
#td müssen in Belegungsvektor verwaltet werden
belegt_2=0
dv2=Float64[2*SimT] # damit kan der Vektor s+1 lang werden
sb=0  # Belkegtaddierer
tb=0  # letze Belegtänedrung
moni_ind=0  # Zeitpunkte für moni
d_moni=3000  # moni Intervall
moni=d_moni  # Zeitpunkt für Statistik der n-Mittelwerte N1, N24
n2_rej=0
n2=0
trace_tv=zeros(Int32.(ceil(SimT/moni)))
#trace_tv=[0.0]
#trace_p2=zeros(Int32(SimT/d_moni))
#trace_p1=zeros(Int32(SimT/d_moni))
mean_belegung=0
t=0.0
                println("   ")
while t<SimT
    global t,ta2,trace_tv,moni_ind,moni,n2,n2_rej,sb,tb,belegt_2

                # events aktuell

                #println("ta1= ",ta1)
events=[ta2,minimum(dv2), moni]
#println("events= ", events)
now=findmin(events)
ev_type=now[2]
ev_time=now[1]
#println("now= ", ev_type," ",ev_time, " belegt_1= ",belegt_1)
if ev_type==1
        # Ankunft 2
    n2=n2+1   # Gesamtzahl ANkünfte
    t=ta2
    sb=sb+(t-tb)*belegt_2
    tb=t
    if belegt_2<s2
                # Eintrag in Vektor
                belegt_2=belegt_2+1
                r_neu=1+(s2-belegt_2)/belegt_2
                r_alt=1+(s2-belegt_2-1)/(belegt_2-1)
                t2_r=t2/r_neu+t
                push!(dv2,t2_r)
                #push!(dv2,t+rand(Exponential(t2)))
              dv2.=(dv2.-t).*(r_alt/r_neu).+t
    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n2_rej=n2_rej+1  # Abweisungszähler
    end
    ta2=t+rand(Exponential(1/la2))
end
if ev_type==2
    # Abgang 2
    # Abgang 1
    ab2=findmin(dv2)
    t=ab2[1]
    sb=sb+(t-tb)*belegt_2
    tb=t
    deleteat!(dv2,ab2[2])
    belegt_2=belegt_2-1
    r_neu=1+(s2-belegt_2)/belegt_2
    r_alt=1+(s2-belegt_2+1)/(belegt_2+1)

    dv2.=(dv2.-t).*(r_alt/r_neu).+t
end
if ev_type==3
    t=moni
moni_ind=moni_ind+1
#println("MONI: n1= ",n1, "   n1_reject=  ", n1_rej)
la_eff=(n2-n2_rej)/d_moni
mean_belegung=sb/d_moni
tv=mean_belegung/la_eff
trace_tv[moni_ind]=tv
#trace_tv=[trace_tv tv]
println("moni= ",moni_ind, "  t= ",t)
n2=0
n2_rej=0
sb=0

moni=t+d_moni
end
end
#plot([trace_p1 trace_p2], linetype=[:steppre :steppre])
println("Ergebnis:")
println("tv=    ",mean(trace_tv))
#plot([fill(15,30) trace_tv[1:30]],yaxis="tv",xaxis="moni Intervall",label=["ohne MBR la=3.0" "mit MBR la=3.6"],color=:black,linestyle=[:solid :dash],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=12,dpi=600)
plot!(trace_tv[1:30],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,legendfontsize=12,dpi=600,label="mit MBR la=3.0",color=:black,linestyle=:dashdot)

png("E:/BUCH/KAP_5/ABB_5/ABB_5_18")
