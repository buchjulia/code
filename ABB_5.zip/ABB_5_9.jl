println("Abb. 5.9 Abweisungswahrscheinlichkeiten und Auslastung Russian Doll")
using Plots
function G_divisor(S,k,r1,r2)
    sum1=0.0
    for b1=0:S-k
        for b2=0:k
            sum1=sum1+(r1^b1)*(r2^b2)/(factorial(b1)*factorial(b2))
        end
    end
    sum2=0.0
    for b1=S-k+1:S
        for b2=0:S-b1
            sum2=sum2+(r1^b1)*(r2^b2)/(factorial(b1)*factorial(b2))
        end
    end
    sum=sum1+sum2
    return sum
end
function p1_reject(S,k,r1,r2)
    sum=0.0
    for b1=S-k:S
            sum=sum+(r1^b1)*(r2^(S-b1))/(factorial(b1)*factorial(S-b1))
        end
   return sum
end
function p2_reject(S,k,r1,r2)
    sum1=0.0
    for b1=0:S-k
            sum1=sum1+(r1^b1)*(r2^k)/(factorial(b1)*factorial(k))
    end
    sum2=0.0
    for b1=S-k+1:S
            sum2=sum2+(r1^b1)*(r2^(S-b1))/(factorial(b1)*factorial(S-b1))
    end
    sum=sum1+sum2
   return sum
end
function Auslastung(S,k,r1,r2)
    sum1=0.0
    for b1=0:S-k
        for b2=0:k
            sum1=sum1+b2*(r1^b1)*(r2^b2)/(factorial(b1)*factorial(b2))
        end
    end
    sum2=0.0
    for b1=S-k+1:S
        for b2=0:S-b1
            sum2=sum2+b2*(r1^b1)*(r2^b2)/(factorial(b1)*factorial(b2))
        end
    end
    sum=sum1+sum2
    return sum
end
S=20
r1=8.0
r2=8.0
P1_reject=zeros(S)
P2_reject=zeros(S)
Last=zeros(S)
for k=1:S
    P1_reject[k]=p1_reject(S,k,r1,r2)/G_divisor(S,k,r1,r2)
    P2_reject[k]=p2_reject(S,k,r1,r2)/G_divisor(S,k,r1,r2)
    Last[k]=Auslastung(S,k,r1,r2)/G_divisor(S,k,r1,r2)/S
end

# ABB_5_9:
plot([P1_reject P2_reject], label=["P1_reject Klaase 1" "P2_reject Klaase 2"],xaxis="k",yaxis="P_reject",color=:black,linestyle=[:solid :dashdot],fontfamily="Arial",xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legend=:topleft,legendfontsize=14,dpi=600,left_margin = 3Plots.mm, right_margin = 18Plots.mm)
p=twinx()
plot!(p,Last, label="Auslastung Klasse 2",fontfamily="Arial",yaxis="Auslastung Klasse 2",color=:black,linestyle=:dash,xguidefontsize=12,yguidefontsize=12,tickfontsizes=12,legendfontsize=10,dpi=600,left_margin = 3Plots.mm, right_margin = 18Plots.mm)
png("E:/BUCH/KAP_5/ABB_5/ABB_5_9")
