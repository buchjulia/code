prrintln("Abb. 5.12 SLA-Werte zu den Monitorzeitpunkten")
using Plots
using Distributions
using StatsBase
#SLA Forderung: p1_rej<4%  p2_reject<6%
function heuristic(rej_1,rej_2,ss_1,ss_2)
    toleranz=0.005
    KPI1=0
    KPI2=0
    if rej_1<(0.08-toleranz) KPI1=1 end
    if rej_2<(0.03-toleranz) KPI2=1 end
    if KPI1==1 && KPI2==0
        ss_1=ss_1-1
        ss_2=ss_2+1
    end
    if KPI2==1 && KPI1==0
        ss_1=ss_1+1
        ss_2=ss_2-1
    end
    return ss_1,ss_2
end


# 2 Bedienerpools je s1, s2=S-s1 Bediener
S=100
s1=50
s2=S-s1
SimT=1000000
la1=2.7  # expo
t1=15.0  # Dauer 1: expo oder detreminitisch,...
la2=3.0  # expo
t2=15.0   # Dau1er 2: expo oder detreminitisch,...
# haben 4 Ereignisquellen ta1, ta2, td1, td2
ta1=0.0
ta2=0.0
#td müssen in Belegungsvektor verwaltet werden
dv1=Float64[2*SimT]
belegt_1=0
belegt_2=0
dv2=Float64[2*SimT] # damit kan der Vektor s+1 lang werden

moni_ind=0  # Zeitpunkte für moni
d_moni=3000  # moni Intervall
moni=d_moni  # Zeitpunkt für Statistik der n-Mittelwerte N1, N24
n1_rej=0
n2_rej=0
n1=0
n2=0
trace_p2=zeros(Int32.(ceil(SimT/moni)))
trace_p1=zeros(Int32.(ceil(SimT/moni)))
#trace_p2=zeros(Int32(SimT/d_moni))
#trace_p1=zeros(Int32(SimT/d_moni))

t=0.0
                println("   ")
                #println("ta1111= ",ta1)
while t<SimT
    global t,ta1,ta2,s1,s2,moni,dv1,dv2,n1,n2,n1_rej,n2_rej,trace_p1,trace_p2,moni_ind,belegt_1,belegt_2
                # events aktuell

                #println("ta1= ",ta1)
events=[ta1,ta2, minimum(dv1), minimum(dv2), moni]
#println("events= ", events)
now=findmin(events)
ev_type=now[2]
ev_time=now[1]
#println("now= ", ev_type," ",ev_time, " belegt_1= ",belegt_1)
if ev_type==1
    # Ankunft 1
    n1=n1+1
    t=ta1
    if belegt_1<s1
                # Eintrag in Vektor
                push!(dv1,t+t1)
                #push!(dv1,t+rand(Exponential(t1)))
                belegt_1=belegt_1+1
    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n1_rej=n1_rej+1
    end
    ta1=t+rand(Exponential(1/la1))
    #ta1=t+1/la1
                    #println("ta222= ",ta1)
end
if ev_type==2
        # Ankunft 2
    n2=n2+1
    t=ta2
    if belegt_2<s2
                # Eintrag in Vektor
                push!(dv2,t+t2)
                #push!(dv2,t+rand(Exponential(t2)))
                belegt_2=belegt_2+1
    else
      #println("n1= ",n1, " n1_rej= ", n1_rej)
        n2_rej=n2_rej+1
    end
    ta2=t+rand(Exponential(1/la2))
end
if ev_type==3
    # Abgang 1
    ab1=findmin(dv1)
    t=ab1[1]
    deleteat!(dv1,ab1[2])
    belegt_1=belegt_1-1
end
if ev_type==4
    # Abgang 2
    # Abgang 1
    ab2=findmin(dv2)
    t=ab2[1]
    deleteat!(dv2,ab2[2])
    belegt_2=belegt_2-1
end
if ev_type==5
    t=moni
moni_ind=moni_ind+1
#println("MONI: n1= ",n1, "   n1_reject=  ", n1_rej)
trace_p1[moni_ind]=n1_rej/n1
trace_p2[moni_ind]=n2_rej/n2
#s1,s2=heuristic(n1_rej/n1,n2_rej/n2,s1,s2)
n1=0
n2=0
n1_rej=0
n2_rej=0
moni=t+d_moni
end
end
#plot([trace_p1 trace_p2], linetype=[:steppre :steppre])
println("Ergebnis:")
println("rho 1=   p1_rej=    ", la1*t1/s1 , "    ", mean(trace_p1))
println("rho 2=   p2_rej=    ", la2*t2/s2 , "    ",mean(trace_p2))
plot([trace_p1[1:100] trace_p2[1:100]], linetype=:steppre,label=["p1_reject" "p2_reject"], linestyle=[:solid :dash], color=:black,yaxis="p_reject",xaxis="Monitor-Intervall ",dpi=600,fontfamily="Arial",guidefontsize=12,tickfontsizes=12,legendfontsize=12)

png("E:/BUCH/KAP_5/ABB_5/ABB_5_12")

#xtickfontsize=18,ytickfontsize=18,xlabel="wavelength",xguidefontsize=18,yscale=:log10,ylabel="flux",yguidefontsize=18,legendfontsize=18)
