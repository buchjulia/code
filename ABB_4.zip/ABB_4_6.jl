println("Abb. 4.6 QQ-Plot")
using StatsPlots
using Distributions
n_samples=2000
X=rand(Exponential(10),n_samples)
plot(qqplot(Exponential,X,fontfamily="Arial",xaxis="theoretisch",yaxis="statistisch", legendfontsize=12,tickfontsize=12,guidefontsize=12,dpi=600,color=:darkgrey))
png("E:/BUCH/KAP_4/ABB_4/ABB_4_6")
