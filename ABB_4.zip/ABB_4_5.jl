println("Abb. 4.5 Visualisierung Wahrscheinlichkeit-Häufigkeitshistogramm")
# Beispieldaten aus Datei "samples"
# https://stackoverflow.com/questions/42204051/multiple-histograms-in-julia-using-plots-jl
using Distributions
using Plots
using StatsBase
n_samples=2000
X=rand(Exponential(10),n_samples)
scatter(X, color=:darkgrey,label="X-Werte",yaxis="X", xaxis="i",fontfamily="Arial",tickfontsizes=10, legendfontsize=12,guidefontsize=12,dpi=600)
#png("D:/My_Drive/BUCH_3/KAP_4_ACCESS/FINAL_ABB/ABB_GRUNDLAGEN_SAMPLES")
akf=autocor(X)
plot(akf,fontfamily="Arial",tickfontsizes=10, legendfontsize=12,guidefontsize=12,dpi=600,markershape = :circle, markersize = 5,xaxis="k",yaxis="akf",grid=:on,label="akf(k)",color=:black,linestyle=:dashdot)
#png("D:/My_Drive/BUCH_3/KAP_4_ACCESS/FINAL_ABB/ABB_GRUNDLAGEN_AKF")
max_data=maximum(X)
min_data=minimum(X)
scale=10
bins=[0.0]
for i=1:10-1
    global bins
    #bins[i]=min_data+i*((max_data-min_data)/scale)
    bins=[bins; i*(max_data-min_data)/scale]
end
#bins = [0.0,0.1];
#bins=[bins;1] # a small and a large bin
println("bins=  ",bins)
#obs = [0.5, 1.5, 1.5, 2.5]; # one observation in the small bin and three in the large
h = fit(Histogram, X, bins)
#plot(h)
plot(h,markersize=1, xlabel="T_i", color=:white, linecolor=:black, ylabel="H(T_i)", label="T_i Histogram",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,dpi=600)
#png("D:/My_Drive/BUCH_3/KAP_4_ACCESS/FINAL_ABB/ABB_GRUNDLAGEN_HISTOGRAM")

# MLR
lambda=fit_mle(Exponential,X)
println("lambda= ",lambda.θ)
hist_theor=rand(scale)
for i=1:scale-1
    global hist_theor
    hist_theor[i]=cdf(Exponential(lambda.θ),bins[i+1])-cdf(Exponential(lambda.θ),bins[i])
end

using StatsPlots
bar2=[h.weights hist_theor[1:scale-1].*n_samples]
groupedbar(bins[1:scale-1],bar2,bar_position=:dodge,bar_width=7.0,color=[:grey :darkgrey],label=["Histogramm" "Exponentialverteilung"],fontfamily="Arial",tickfontsizes=12, xaxis="Wertebereich", yaxis="Anzahl",legendfontsize=12,guidefontsizes=12,dpi=600)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_5")

println("         TEST       ")
# Hyypothesentest
using HypothesisTests
Test=OneSampleADTest(X,Exponential(lambda.θ))
println(" ")
println("Test=  ",Test)

Test2=ChisqTest(hcat(h.weights,Int32.(ceil.(hist_theor[1:scale-1].*n_samples))))
println("Test2=  ",Test2)
println("h= ",h.weights)
println("thor= ",Int32.(ceil.(hist_theor.*n_samples)))
