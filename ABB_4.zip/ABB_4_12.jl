println("Abb. 4.12 Größen der Hauptseite")
using Distributions
using Plots
sig=1.37
mu=8.37
lower_b=100
upper_b=2*10^6
pdf_logn=rand(upper_b)
pl=rand(upper_b)
for i=lower_b:upper_b
    pl[i]=i
    pdf_logn[i]=pdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)
    #pdf_logn[i]=cdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)-cdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)
end
plot(pl[lower_b:40*lower_b],pdf_logn[lower_b:40*lower_b],label="pdf(L Hauptseite)",ylabel="pdf(L)", xaxis="Seitengröße Bytes",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,color=:black,linestyle=:solid)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_12")
