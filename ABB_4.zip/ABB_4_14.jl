println("Abb. 4.14 Wahrscheinlichkeiten der Anzahl embedded Objects")
using Distributions
using Plots
alpha=1.1
min_o=2
max_o=55
p_o=zeros(55)
obj=zeros(55)
for i=1:55-1
    obj[i]=i
    p_o[i]=alpha*min_o^alpha/(i^(alpha+1))
    #p_o[i]=pdf(truncated(Pareto(alpha),min_o,max_o),i)
    p_o[i]=cdf(truncated(Pareto(alpha),min_o,max_o),i+1)-cdf(truncated(Pareto(alpha),min_o,max_o),i)
end
obj=obj.-2
plot(obj[2:15].+2,p_o[2:15],seriestype=:step,label="P(#objects)",ylabel="P(#objects)", xaxis="# objects",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,color=:black)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_14")
