println("Abb. 3.4 Sample-Werte Xi")
using Distributions
using Plots
X=rand(Exponential(10),100)
scatter(X,label="X-Werte",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,dpi=600,color=:darkgrey)
png("D:/BUCH/Github_Zip/KAP_4/ABB_4_2")
