println("Abb. 4.2 Verweilzeit Tv für die 3 Lastgeneratoren" )
using Random
using Plots
using Distributions
# Mittelwert immer gleich
MITTE=500
# C-Intervallbreite
C_Int=50
#
Tb=rand(C_Int) # Vektor für E(Bedienzeit)
Tb2=rand(C_Int) # Vektor für E(quadratische Bedienzeit)
Tw=rand(C_Int)  # Vektor für E(Wartezeit)
Tv=rand(C_Int)  # Vektor für E(Verweilzeit)
C=rand(C_Int)   # Vektor für Übertragungsrate
rho=rand(C_Int) # Vektor für Last
la=1    # Ankunftsrate
min_C_plus=10 # minimale Übetrgagungsrate
# Berechnung Tv für LP=500
for i=1:C_Int
    C[i]=i+500+min_C_plus
    Tb[i]=MITTE/C[i]
    Tb2[i]=Tb[i]^2;
    rho[i]=la*Tb[i]
    Tw[i]=la*Tb2[i]/(2*(1-rho[i]))
    Tv[i]=Tw[i]+Tb[i]
end
plot(C,Tv,label="LP = 500",ylabel="Tv [ZE]", xaxis="C Bytes/ZE",fontfamily="Arial",tickfontsizes=12, legendfontsizes=12,guidefontsizes=12,dpi=600,color=:black,linestyle=:dashdot)
# Berechnung Tv für gleichverteilte Paketlängen
L=400
for i=1:C_Int
    C[i]=i+500+min_C_plus
    Tb[i]=MITTE/C[i]
    Tb2[i]=0
    for j=MITTE-L:MITTE+L
    Tb2[i]=Tb2[i]+(j/C[i])^2
    end
    Tb2[i]=Tb2[i]/(2*L+1)
    rho[i]=la*Tb[i]
    Tw[i]=la*Tb2[i]/(2*(1-rho[i]))
    Tv[i]=Tw[i]+Tb[i]
end
plot!(C,Tv,label="100 < LP < 900",ylabel="Tv [ZE]", xaxis="C [Bytes/ZE]",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,dpi=600,color=:black,linestyle=:dash)
# Berechnung Tv für bimodale Verteilung bei MITTE-L und MITTE+L
for i=1:C_Int
    C[i]=i+500+min_C_plus
    Tb[i]=MITTE/C[i]
    Tb2[i]=0.5*((MITTE-L)/C[i])^2+0.5*((MITTE+L)/C[i])^2
    rho[i]=la*Tb[i]
    Tw[i]=la*Tb2[i]/(2*(1-rho[i]))
    Tv[i]=Tw[i]+Tb[i]
end
plot!(C,Tv, label="LP \u2208 {100, 900}",ylabel="Tv", xaxis="C Bytes/Δt",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,dpi=600,color=:black,linestyle=:solid)
png("D:/BUCH/Github_Zip/KAP_4/ABB_4_2")
