println("Abb. 4.16 Berechnung des Zufallswertes")
using Distributions
using Plots
CDF_EXP=rand(50)
for i=1:50
    CDF_EXP[i]=cdf(Exponential(10),i)
end
plot(CDF_EXP,fontfamily="Arial",tickfontsizes=12, yaxis="cdf F = P(X ≤ x)", xaxis="x",label="Exponentialverteilung",legendfontsize=12,guidefontsize=12,dpi=600,color=:black,linestyle=:dash)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_16")
