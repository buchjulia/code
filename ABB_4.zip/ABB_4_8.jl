println("Abb. 4.8a DL Interarrivaltime der Pakete, Abb. 4.8b DL Paketlängen")
using Plots
using Distributions
mi=10
ma=100
xx=zeros(ma)
for i=1:ma;
    xx[i]=i
end
plot(xx[mi:ma],pdf.(GeneralizedExtremeValue(55,6,0.0),[mi:ma]),xaxis="iat ms",yaxis="pdf",label=" pdf(iat DL Paket)", color=:black,linestyle=:solid,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_8a")
mi=50
ma=250
par=rand(ma)
xx=rand(ma)
#b=24;
for i=1:ma;
    xx[i]=i
end
plot(xx[mi:ma],pdf.(GeneralizedExtremeValue(120,36,0.0),[mi:ma]),label="pdf(UL Paketlänge)",ylabel="pdf(Pl)", xaxis="Paketlänge Bytes",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,dpi=600,color=:black,linestyle=:solid)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_8b")
#plot(xx[mi:ma],pdf.(GeneralizedExtremeValue(45,5.7,0.0),[mi:ma]),label="UL Paketgröße [Bytes]",color=:black,linestyle=:dash,fontfamily="Arial",tickfontsizes=10, legendfont=(10,"Arial"),guidefontsize=12,dpi=600)
#plot(xx[mi:ma],pdf.(GeneralizedExtremeValue(120,36,0.0),[mi:ma]),label="pdf(Paketänge DL )",xaxis="Paketlänge [Bytes]",yaxis="pdf",color=:black,linestyle=:solid,fontfamily="Arial",tickfontsizes=10, legendfont=(10,"Arial"),guidefontsize=12,dpi=600)
