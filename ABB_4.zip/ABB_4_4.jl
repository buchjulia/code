println("Abb. 4.4 Korrelationsverlauf von X")
using Distributions
using Plots
using StatsBase
X=rand(Exponential(1),100)
# X ist aus unabhängigen Samples generiert => Korrelation gering
akf=autocor(X,demean=true)
plot(akf,label="akf",markershape=:auto,xaxis="k",yaxis="akf(k)",fontfamily="Arial",tickfontsizes=10, legendfontsize=12,guidefontsizes=12,dpi=600,color=:darkgrey)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_4")
