println("Abb. 4.13 Embedded objects Seitengröße")
using Distributions
using Plots
sig=2.36
mu=6.17
lower_b=50
upper_b=2*10^6
pdf_logn=rand(upper_b)
pl=rand(upper_b)
for i=lower_b:upper_b
    pl[i]=i
    pdf_logn[i]=pdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)
    #pdf_logn[i]=cdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)-cdf(truncated(LogNormal(mu,sig),lower_b,upper_b),i)
end
plot!(pl[500:2000],pdf_logn[500:2000],label="pdf(L embedded objects)",ylabel="pdf(L)", xaxis="Seitengröße Bytes",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,color=:black,linestyle=:dashdot)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_13")
