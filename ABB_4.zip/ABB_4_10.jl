println("Abb. 4.10 Lesezeit")
using Distributions
using Plots
la=0.006
pdf_exp=rand(500)
r_time=rand(500)
    for i=1:500
        r_time[i]=(i-1)
        #pdf_exp[i]=cdf(Exponential(1/la),i)-cdf(Exponential(1/la),(i-1))
        pdf_exp[i]=pdf(Exponential(1/la),i)
    end
    plot(r_time,pdf_exp,label="pdf(FTP Lesezeit)",ylabel="pdf(Lesezeit)", xaxis="Lesezeit s",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,color=:black,linestyle=:solid)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_10")
