println("Abb. 4.9 FTP Filegröße")
using Distributions
using Plots
sig=0.35
mu=14.45
pdf_logn=rand(5000)
Fl=rand(5000)
for i=1:5000
    Fl[i]=1000*(i-1)
    pdf_logn[i]=pdf(truncated(LogNormal(mu,sig),0,5*10^6),1000*(i-1))
    #pdf_logn[i]=cdf(truncated(LogNormal(mu,sig),0,5*10^6),1000*(i))-cdf(truncated(LogNormal(mu,sig),0,5*10^6),1000*(i-1))
end
plot(Fl,pdf_logn,label="pdf(FTP Filegröße)",ylabel="pdf(Fl)", xaxis="Filegröße Fl Bytes",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,color=:black,linestyle=:solid)
png("E:/BUCH/KAP_4/ABB_4/ABB_4_9")
