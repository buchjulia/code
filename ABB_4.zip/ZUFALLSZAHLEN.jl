println(" Abschn. 4.5.2 Zufallszahlen")
using Distributions
println("trunc_log_normal", rand(truncated(LogNormal(0.5,0.1),1,5),5))
println("exponential", rand(Exponential(1),5))
println("trunc_areto", rand(truncated(Pareto(1.2),20,250),5))
println("extreme value", rand(GeneralizedExtremeValue(45.0,5.0,0.0),5))
println("Gumbel value", rand(Gumbel(45.0,5.0),1))
Z=rand(Gumbel(45.0,5.0),1)
println("Z= ",100*Z[1])
