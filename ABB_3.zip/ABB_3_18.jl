println("Abb. 3.18 Extremes.jl Diagnostics Plot")
using Distributions
using Plots
using StatsBase, Plots,DelimitedFiles
samples=readdlm("D:/BUCH/Github_Zip/KAP_3/SAMPLES.csv",Float64)
thr=15
pot = filter(x -> x > thr, samples).-thr
k=size(pot)[1]
println("k= ", k)
using DataFrames, Extremes
using Cairo, Gadfly, Fontconfig  # For saving figures in png or pdf
fm = gpfit(pot)
println("GPD fm= ", fm)
set_default_plot_size(21cm ,16cm)
p = diagnosticplots(fm)
draw(PNG("D:/BUCH/Github_Zip/KAP_3/ABB_3_18.png",dpi=600), p)
