println("Abb. 3.14 Mean Residual Life (q_max)")
# EInlesen der Messwerte
using DelimitedFiles, Plots
samples=readdlm("D:/BUCH/Github_Zip/KAP_3/SAMPLES.csv",Float64)[:,1]
mrl=zeros(30)
for i=1:30
pot = filter(x -> x > i, samples).-i
k=size(pot)[1]
mrl[i]=sum(pot)/k
end
plot(mrl,label="MRL(q_max)",color=:black,xaxis="q_max", yaxis="Mean Residual Life",legendposition=:topleft,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600 )
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_14")
