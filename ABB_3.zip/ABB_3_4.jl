println("Abb. 3.4 Übertragungsraten Positionsmeldungen" )
# alle Werte in [43] vorgegeben
using Plots
xv=1:17;
interval=[1000,1000,720,480,360,288,240,206,180,160,144,131,120,111,103,100,100]
rate=1000 ./interval
println("v_rate=[2] ",rate[2])
println("v_interval[2]= ",interval[2])
V=12
plot((xv[1:V-1].-1).*10,interval[1:V-1],ylabel="interval ms",legend=:topleft,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,markershape = :cross, markersize = 5,xaxis="v km/h",grid=:on,label="interval",color=:black,linestyle=:dashdot,left_margin = 5Plots.mm, right_margin = 15Plots.mm)
p=twinx()
plot!(p,(xv[1+1:V].-1).*10,rate[1+1:V],ylabel="rate Hz", xaxis="v km/h",label="rate",fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600,markershape=:circle,color=:black,markersize = 3,linestyle=:dash,left_margin = 5Plots.mm, right_margin = 15Plots.mm)
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_4")
