println("Abb.3.7 Paketlängenverteilung")
# Paketelängen aus [45]
# vereinfachter (Treppenanzahl) Verteilugsverlauf
using Plots
cdf_pl=zeros(460)
cdf_pl[1:130].=0;
println(cdf_pl[7])
cdf_pl[131:300].=0.3;
cdf_pl[301:350].=0.5;
cdf_pl[351:450].=0.7;
cdf_pl[451:460].=1.0;
y=[0.3,0.5,0.7,1.0]
# Treppen-Punkte in Diagramm
plot(x, y, seriestype = :scatter, color=:black,label="Paketlängenverteilung")
# Linien in Diagramm
plot!(cdf_pl,linestyle=:dash,primary=false,legend=:top,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,dpi=600,color=:black, yaxis="cdf", xaxis="Paketlängen Bytes")
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_7")
