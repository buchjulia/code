println("Abb. 3.15 Histogramm und GPD-Verteilung in [Qi] Intervallen")
using Distributions
using Plots
using StatsBase, Plots,Random, DelimitedFiles
# Import der Messwerte
samples=readdlm("D:/BUCH/Github_Zip/KAP_3/SAMPLES.csv",Float64)[:,1]
K=size(samples)[1]
# Schwellwert setzen
thr=10 # hier kann experimentiert werden, bei thr=15 noch gute Approximation
# PoT Werte ermitteln
pot = filter(x -> x > thr, samples).-thr
k=size(pot)[1]
println("k= ", k) # Anzahl der PoT-Werte
using  Extremes
# ERmittlung der GPD-Parameter der PoT-Werte
fm = gpfit(pot)
XX=fm.θ̂
x1=exp(XX[1])  # Achtung: wegen log-Ergebnis korrigieren
x2=XX[2]
println(" fm= ", XX[1]," ",XX[2])
println("GPD fm= ", fm)
# wir nennen jetzt die PoT unsere "observations"
obs=pot
# und berechnen das Histogramm
max_data=maximum(obs)
min_data=minimum(obs)
scale=100
interval=(max_data-min_data)/scale
bins=[0.0]
for i=1:scale-1
    global bins
    #bins[i]=min_data+i*((max_data-min_data)/scale)
    bins=[bins; i*interval]
end
println("bins=  ",bins)
h = fit(Histogram, obs, bins)
# Ausgabe Histogramm
plot(h, dpi=:600, fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,xlabel="[Qi] Intervalle ", color=:lightgrey,linecolor=:black, ylabel="H([Qi]) P([Qi])", label="[Qi] Histogramm")
# und legen daneben die ermittelte GPD-Modellverteilung
pdf_mod=rand(scale)
cdf_mod_invers=rand(scale)
xax=rand(scale)
for i=1:scale;
    xax[i]=i*interval
    pdf_mod[i]=cdf(GeneralizedPareto(x1,x2),i*interval)-cdf(GeneralizedPareto(x1,x2),(i-1)*interval)
    cdf_mod_invers[i]=cdf(GeneralizedPareto(x1,x2),i*interval)
end
scatter!(xax,pdf_mod.*k,label="P([Qi]) Modell(θ^) ",markersize=2, color=:black)
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_15")
