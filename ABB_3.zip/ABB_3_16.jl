println("Abb. 3.16 Return Period für PoT in Q Messungen")
using Distributions
using Plots
using StatsBase,Random, DelimitedFiles
# Import der Werte von der "Parent Distribution"
samples=readdlm("D:/BUCH/Github_Zip/KAP_3/SAMPLES.csv",Float64)
K=size(samples)[1]
using  Extremes
# Wahrscheinlichkeit für Überschreitung = k/K
thr=15
pot = filter(x -> x > thr, samples).-thr
k=size(pot)[1]
println("k= ", k, "rate= ",k/K)
P_pot=k/K
# GPD Parameter bestimmen
fm = gpfit(pot)
println("GPD fm= ", fm)
# Returnlevel für pot=Q=2 <=> q=12
u=thr
XX=fm.θ̂
x1=exp(XX[1])
x2=XX[2]
# return level
z_p=zeros(20)
for i=1:20
z_p[i]=(x1/x2)*((i)^x2-1)
end
# in Abb. 3.16: Return Period in den Überschereitungswerten
scatter(z_p ,xlabel="Return Period",legend=:topleft, label="RL_Q(m)",ylabel="Return Level", color=:darkgrey,markersize=2.0,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600)   # rlp ohne Extremes
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_16.png")
println("Abb. 3.17 Return Period für PoT in q-Messungen")
# d.h. der Q-Bereich wir gedehnt um 1/P_pot
z_p=zeros(100)
for i=1:100  # periode i muss hinreichend gross sein
z_p[i]=thr+(x1/x2)*((P_pot*(10000+i*100))^x2-1)
end
scatter([10000:100:20000],z_p,xlabel="Return Period",legend=:topleft, label="RL_q(m)",ylabel="Return Level", color=:darkgrey,markersize=2.0,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsize=12,dpi=600)   # rlp ohne Extremes)
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_17.png")
