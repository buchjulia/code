println(" Abb. 3.3 Wert/Nutzen für hard real time und soft real time")
using Plots
# soft rt : R-Werte
R=zeros(175)
# hard rt : U-Werte (utility)
U=zeros(175)
U[1:25].=100
U[51:175].=0
for i=1:175
    R[i]=100/i^0.15
    if i<175 R[i]=100-0.0267*i else R[i]=(100-0.0267*175)/(i-175)^0.15 end
    R[i]=100*cos(i/175)
end
plot([R U],fontfamily="Arial",tickfontsizes=12, label=["R(soft rt)" "U(hard rt)"],yaxis="Wert",xaxis="Übertragungsdauer ms",legendfontsizes=12,guidefontsizes=12,dpi=600,color=:black,linestyle=[:dash :solid])
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_3")
