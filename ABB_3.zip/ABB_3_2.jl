println("Abb. 3.2 Einfluss der Verzögerung h auf QoC")
# s.a. https://www.youtube.com/watch?v=FWzauif2N1k
using Plots
time=2500
theta=zeros(time)
TIAT=zeros(time)
w_speed=zeros(time)
w_speed[1]=0.3
w=1.0;
l=1;
#o=0.3;
dt=0.04;
θ=0.3
t=0.0;
g=9.8
for i=2:time-1
    global l,θ,dt,t
# ! Durchlauf 1: hier kann die Verzögerung auf h gestellt werden := speed[i]
    w_speed[i+1]=w_speed[i]-(g/l)*θ*dt
# ! Durchlauf 2: hier kann die Verzögerung auf 2h gestellt werden := speed[i-1]
#    w_speed[i+1]=w_speed[i-1]-(g/l)*θ*dt
    #w=w-(g/l)*θ*dt  # Regelung: Winkelgeschwindigkeit w proportional reduzieren
    θ=θ+w_speed[i+1]*dt      # neuer Winkel := alter Winkel + w*dt
    t=t+dt
    theta[i]=θ
    TIAT[i]=sum(abs.(theta))/i
end
println("MAX THETA= ", maximum(theta))
I=1500
# Durchlauf 1 Diagramm für h
plot([theta[I:I+60] w_speed[I:I+60]], label=["Fehler h" "Winkelgeschwindigkeit h"],
legend=:topleft,fontfamily="Arial",tickfontsizes=12, legendfontsize=12,
guidefontsizes=12,dpi=600,markershape = [:circle :cross],
markersize = 3,xaxis="Intervall",grid=:on,color=:black,
linestyle=[:dashdot :dot])
# ! Durchlauf 2 Digramm für 2h in Durchlauf 2 zufügen
#plot!(theta[I:I+60], label="Fehler 2*h",legend=:topleft,
#fontfamily="Arial",tickfontsizes=12, legendfontsize=12,
#guidefontsizes=12,dpi=600,color=:grey,xaxis="Intervall",
#grid=:on,linestyle=:dash)
# ! nach Durchlauf 2 Diagramm abspeichern
#png("D:/BUCH/Github_Zip/KAP_3/ABB_3_2")
