println(" Abb. 3.19 Simulation BUFFER_SIM")
using Distributions
using Random
using DataStructures
using Plots
Ts=1000
n=0.0
ta=0.0
td=2*Ts
time=0.0
lambda=1.0
mue=1.2
#println("===SIMULATION ======")
pot=[]
n_max=20
while time<Ts
    global time,ta,td,n,pot
    if ta<=td
        time=ta
        n=n+1
        #println("n+ = ",n)
        if n>n_max push!(pot,n-n_max) end
        ta=time+rand(Exponential(1/lambda))
        if n==1
            td=time+rand(Exponential(1/mue))
            tb=time
        end
    else
        time=td
        n=n-1
        #println("n- =",n)
        if n>0
            td=time+rand(Exponential(1/mue))
        else
            td=2*Ts
        end
    end
end
println("k= ", length(pot))
scatter(pot,markersize=2)
