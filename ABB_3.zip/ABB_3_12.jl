println("Abb. 3.12 Peak over Threshold Messungen")
using Plots
using Distributions
using Plots
K=500
# als Besipiel nehmen wir die truncated N-Verteilung
samples=rand(truncated(Normal(10.0,4.0),0,Inf),K)
# Diagramm aller Messwertew

# Threshold = 15 setzen
Threshold=15
#plot!([1:1:K],zeros(K).+Threshold, linestyle=:dash, color=:black, label="threshold")
PoT=0 # Anzahl von PoT-Werten
PoT_Ind=[]  # Inidizes der PoT-Werte
for i=1:K
    global PoT, PoT_Ind
    if samples[i]>Threshold
        PoT=PoT+1
        PoT_Ind=[PoT_Ind;i]
    end
end
println("Anzahl=  ", PoT)
println("PoT_Ind= ",PoT_Ind)
# Diagramm der Messwerte
scatter(samples, xaxis="Messung",yaxis="q", markersize=1,dpi=:600,color=:darkgrey, fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12, label=false,thickness_scaling = 1.0)
# Heraushebung der PoT-Werte
scatter!(PoT_Ind,samples[PoT_Ind], markersize=3,dpi=:600,color=:black, fontfamily="Arial",tickfontsizes=12, legendfontsize=12,guidefontsizes=12,thickness_scaling = 1.0, label="above")
# Einzeichnen Linie Threshold
plot!([1:1:K],zeros(K).+Threshold, label="threshold", color=:black, linestyle=:dash)
png("D:/BUCH/Github_Zip/KAP_3/ABB_3_12")
