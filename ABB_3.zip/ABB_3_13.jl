println(" Abb. 3.13 GPD Dichtefunktion")
using Plots
using Distributions
# ! für die 3 Diagrammlinien sind die Parameter σ und ξ zu setzen
# GeneralizedPareto(0.0,σ,ξ)
# das ergibt 3 Durchläufe mit plot, plot!, plot!; linestyle:= [solid, dot, dashdot] 
# erster Durchlauf mit σ=2,ξ=1:
pdf_gpd=pdf.(GeneralizedPareto(0.0,2,1),0.0:0.1:5)
plot([0:50]./10, pdf_gpd, label="GPD(σ=1, ξ=1)",fontfamily="Arial",tickfontsizes=12,linestyle=:solid,color=:black,yaxis="PDF",xaxis="x",legendfontsize=12,guidefontsizes=12,dpi=600)
# bei drittem Durchlauf Abbildung sichern:
# png("E:/BUCH/KAP_3/ABB_3/ABB_3_13")
