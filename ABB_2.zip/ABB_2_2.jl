println("Abb. 2.2 Erweitertes perzeptuelles Modell")
using Plots
using Statistics
# Initialisierung
QoE=zeros(500)
S=zeros(500)
MOS=zeros(500)
MOS_P=zeros(500)
# angenommene QoS Änderungspunkte
t1=100
t2=300;
t3=500;
S1=4
S2=4;
S3=4
# Vergesslichkeitskurven
for i=1:t1;
    QoE[i]=90-90*exp(-(i+10)/(S1*10))
end
for i=t1+1:t2
    j=i-t1
    QoE[i]=QoE[t1]-QoE[t1]*(1-exp(-(0.5*j)/(S2*10)))/2
end
for i=t2+1:t3
    j=i-t2
    QoE[i]=2*QoE[t2]-QoE[t2]*exp(-(0.5*j)/(S3*10))
end
for i=1:t1;
    S[i]=QoE[t1]+5
end
for i=t1+1:t2
    S[i]=QoE[t2]-10
end
for i=t2+1:t3
     S[i]=QoE[t3]+5
end
for i=1:500
    MOS[i]=mean(QoE[20:500])
    MOS_P[i]=mean(S[20:500])
end
plot([QoE[20:500] S[20:500] MOS[20:500] MOS_P[20:500]],dpi=600,xaxis="t",yaxis="R",legend=:bottomright,tickfontsizes=12,legendfontsize=12,guidefontsize=12,fontfamily="Arial",color=:black,linestyle=[:solid :dash :dashdot :dot], label=["QoE(t)" "R(t)" "MOS_R" "MOS_QoE"])
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_2")
