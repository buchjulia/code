println("Abb. 2.8 Subjektive Zufriedenheit mit Übertragungsraten für verschiedene Displays")
using Plots
# 3 Displaytypen s. Tab. 2.7
f1(r)=(-3.035*r^(-0.5061)+1.022)*5
f2(r)=(-4.85*r^(-0.647)+1.011)*5
f3(r)=(-17.53*r^(-1.048)+0.9912)*5
f4(r)=4.5
# Bewertungsintervalle festlegen
r1= [100:50:10000]
r2= [100:50:5000]
r3= [100:50:1000]
plot([r1,r2,r3,r3],[f1,f2,f3,f4],fontfamily="Arial",tickfontsizes=10,legend=:right,legendfont=(12,"Arial"),guidefontsize=12,dpi=600, color=:black,xscale = :log10, yaxis="MOS-Wert", xaxis="Übertragungsrate kbit/s",linestyle=[:solid :dash :dashdot :dot], label=["1080p" "720p" "360p" "MOS = 4.5"])
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_8")
