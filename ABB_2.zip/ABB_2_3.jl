println("Abb. 2.3 Video-Bewertungen , MOS-Werte μ nach [20], σ=min(MOS-L,H-MOS)/2")
using Distributions
using Plots
using Statistics
z=rand(1000)
L=1
H=5
for i=1:1000
    z[i]=1+i*(H-L)/1000
end
# 3-Parameter-Modell Tab. 2.7 für 1080p
a=-3.035
b=-0.5061
c=1.022
# Bewertung für 2 Übertragungsraten
r1=6000
r2=3000
MOS1=(a*(r1^b)+c)*5
MOS2=(a*(r2^b)+c)*5
#MOS1=3.0
s1=min(MOS1-L,H-MOS1)/2
#MOS2=4.0
s2=min(MOS2-L,H-MOS2)/2
v1=rand(999)
v2=rand(999)
for i=1:999
v1[i]=cdf(Truncated(Normal(MOS1,s1),L,H),z[i+1])-cdf(Truncated(Normal(MOS1,s1),L,H),z[i])
v2[i]=cdf(Truncated(Normal(MOS2,s2),L,H),z[i+1])-cdf(Truncated(Normal(MOS2,s2),L,H),z[i])
end
plot(z[900:999],[v1[900:999] v2[900:999]],linestyle=[:solid :dash],legend=:top,tickfontsizes=10,legendfont=(12,"Arial"),guidefontsize=12,fontfamily="Arial",dpi=600,color=[:black :black],label=["QoE r=6000 kbit/s" "QoE r=3000 kbit/s "],xaxis="QoE",yaxis="Häufigkeit")
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_3")
