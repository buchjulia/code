println(" Abb. 2.7 Ergebnis Approximation E-Modell mit neuronalem Netz, Fehler relativ = 0.0248")
using Plots
using Random
using StatsBase
using Flux
using IterTools:ncycle
# QoS-Werte der Übertragung
d=100
Id= 0.0267*d
Bpl=4
# Wertebereiche für Messungen
BurstR=1
Loss=20
Werte=20
loss=range(0,stop=Loss,length=Werte)
burst=range(1,stop=BurstR,length=Werte)
Ie=0            # für G.711, sonst in [0, 40]
# E-Modell R(loss,burst)=93-Id-loss/((loss/burst)+Bpl)
R(loss,burst)=93-Id-(Ie+(95-Ie)*loss/(loss/burst+Bpl))
# unsere Messungen: (loss, burst)
X_train=[0 2; 0 3; 0 4; 0 6; 0 8;
   5 2; 5 3; 5 4; 5 6; 5 8;
   10 2; 10 3; 10 4; 10 6;10 8;
   ]
# Normierung der Messungen in [0, 1]
X_train=X_train./[Loss BurstR]
println("X_train_norm= ", X_train)
s_train=size(X_train,1) # Anzahl der Trainingswerte
Y_train=rand(s_train)   # genau so viele MOS-Werte nach E-Modell
Y_train.=R.(X_train[:,1],X_train[:,2])
Y_train=Y_train./100    # Normierung MOS-Werte in [0, 1]
println("Y_train  ", Y_train)
# eben so Ermittlung der Validierungswerte
X_val=[0 3.5; 5.5 6.5; 10 2.5;1 2.5; 4.5 5.5; 10 1.5]
X_val=X_val./[Loss BurstR]
s_val=size(X_val,1)
#X_val=X_train[1+s_val,:]
Y_val=rand(s_val)
Y_val.=R.(X_val[:,1],X_val[:,2])
Y_val=Y_val./100
println("Y_val= ", Y_val)
# Neuronales Netz für Approximation E-Modell
Approx= Chain(Dense(2,2,σ),Dense(2,2,σ),    # Inpaut ist die Rate
Dense(2,1,σ))  # 1 Output ist der QoS
# optional abspeichern für Vergleichbarkeit
function mseLoss(x, y)      # Regresission mit min. quadr. Fehler
loss = Flux.mse(Approx(x), y) # Fehler ergibt sich aus mittl. quadr. Fehler
return loss
end
# Einstellung für Training: immer 2 Messwerte nehmen, Reihenfolge zufällig
train_loader=Flux.Data.DataLoader((X_train', Y_train),batchsize=2,shuffle=true)
m=Flux.params(Approx) # m= Modellparameter
# Trainieren der Modellparameter m über 200 Epochen
Flux.train!(mseLoss,m,ncycle(train_loader,200),Flux.ADAM(0.01)) # 1 epoche
# Validierung
# Schritt 1: Y_mod aus X_val ermitteln
Y_mod=rand(size(X_val,1))
for i=1:size(X_val)[1]
Y_mod[i]=Approx(X_val[i,1:2])[1]
end
# Schritt 2, Ergebnisausgabe und  Berechnung Fehler aus Y_val - Y_mod
println(" ")
println("ERGEBNIS normiert")
println("Soll= ",Y_val)
println("Appr= ", Y_mod)
println( "ERROR =", sqrt(sum((Y_val.-Y_mod).^2)/s_val))
println("ERGEBNIS original")
println("Soll= ",Y_val.*100)
println("Appr= ", Y_mod.*100)
println( "ERROR =", sqrt(sum((100*Y_val.-100*Y_mod).^2)/s_val))
println( "ERROR relativ =", sqrt(sum((100*Y_val.-100*Y_mod).^2)/s_val)/mean(100*Y_val))
Y_result=[100*Y_val 100*Y_mod]
#plot([100*Y_val 100*Y_mod],dpi=300,shape=:circle, label=["R_Valid" "R_Appr"],color=:black, linestyle=[:solid :dashdot])
plot(Y_result,fontfamily="Arial",tickfontsizes=12, legendfont=(10,"Arial"),guidefontsize=12,dpi=600,markershape=:auto, xaxis="Messung",yaxis="R-Wert", label=["R_Valid" "R_Appr"],color=:black, linestyle=[:solid :dash])
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_7")
