println("Abb. 2.11 Vergleich n1=n2=n3=1 mit Erhöhung n2=3")
# Erklärungen s. Abb. 2.10
# !!! Abb. 2.10 zuerst aufrufen, danach Abb. 2.11
using NLsolve
using Plots
iter=6              # wir müssen Wertevorrat geringer machen für Experiment nach oben
trace_r=rand(iter,3)
trace_qoe=rand(iter,3)
qoe_soll=rand(iter)
bw=rand(iter)
n1=1
n2=3
n3=1
for i=1:iter
R=500*i
bw[i]=R
function f!(F,x)
    F[1] = (-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)-2*(-17.53*x[3]^-1.048+0.9912)
    F[2]=-2*(-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)+(-17.53*x[3]^-1.048+0.9912)
    F[3] = R-n1*x[1]-n2*x[2]-n3*x[3]
end
y=nlsolve(f!,[ 505.1; 500.2;160.1], autodiff = :forward)
println("   ")
#println("FN= ",NLsolve.SolverResults.Zero)
println("ERGEBNIS = ",y.zero)
#PROBE
r=y.zero
trace_r[i,:]=r
println("Summe= ",sum(r))
QoE_1080=(-3.035*r[1]^(-0.5061)+1.022)*5
QoE_720=(-4.85*r[2]^(-0.647)+1.011)*5
QoE_360=(-17.53*r[3]^(-1.048)+0.9912)*5
println("QoE_1080 =", QoE_1080)
println("QoE_720 =", QoE_720)
println("QoE_360 =", QoE_360)
trace_qoe[i,1]=QoE_1080
trace_qoe[i,2]=QoE_720
trace_qoe[i,3]=QoE_360
qoe_soll[i]=4.5
end
plot!(bw,trace_qoe,fontfamily="Arial",legend=:right,legendfontsize=12,tickfontsizes=12,guidefontsizes=12,xaxis="Gesamtrate kbit/s",dpi=600,color=:black, linestyle=[:solid :dash :dashdot],yaxis="Fair MOS für Display",label=["1080p [1,3,1]" "720p [1,3,1]" "360p [1,3,1]"])
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_11")
