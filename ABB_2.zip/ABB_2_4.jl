println("Abb.2.4 Ermittlung des Anteiles zufriedener Nutzer mit der Video-Qualität")
using Distributions
using Plots
using Statistics
z=rand(1000)
L=1
H=5
# Bewertungsintervalle justieren
for i=1:1000
    z[i]=1+i*(H-L)/1000
end
# Modellparameter aus Tab. 2.7
a=-3.035
b=-0.5061
c=1.022
r1=6000
r2=3000
MOS1=(a*(r1^b)+c)*5
MOS2=(a*(r2^b)+c)*5
s1=min(MOS1-L,H-MOS1)/2
s2=min(MOS2-L,H-MOS2)/2
# Berechnung Anteil zufriedener Nutzer= 1- Anteil unzufriedener Nutzer
acc1=rand(999)
acc2=rand(999)
for i=1:999
acc1[i]=1-cdf(Truncated(Normal(MOS1,s1),L,H),z[i])
acc2[i]=1-cdf(Truncated(Normal(MOS2,s2),L,H),z[i])
end
plot(z[900:999],[acc1[900:999] acc2[900:999]],legendfont=(12,"Arial"),tickfontsizes=12,guidefontsize=12,fontfamily="Arial",legend=:inside,dpi=600,color=[:black :black],linestyle=[:solid :dash], label=["Anteil r = 6000" "Anteil r = 3000"],xaxis="Zufriedenheits-QoE Θ",yaxis="Anteil Nutzer(Θ)")
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_4")
