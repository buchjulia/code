println("Abb. 2.9 Aufteilung der Gesamtrate für gleichen MOS")
using NLsolve
using Plots
# 6 Werte für Raten festlgen
iter=6
# Felder für Ergebnisse
trace_r=rand(iter,3)
trace_qoe=rand(iter,3)
bw=rand(iter)
# Berechnung der MOS-Werte
for i=1:iter
r=500*i
bw[i]=r
# Modell - Gleichungssystem
function f!(F,x)
    F[1] = (-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)-2*(-17.53*x[3]^-1.048+0.9912)
    F[2]=-2*(-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)+(-17.53*x[3]^-1.048+0.9912)
    F[3] = r-x[1]-x[2]-x[3]
end
# Lösung des Gleichungssystems
y=nlsolve(f!,[ 505.1; 500.2;160.1], autodiff = :forward)
println("   ")
println("ERGEBNIS = ",y.zero)
# Probe, ob Summe "stimmt"
r=y.zero
trace_r[i,:]=r
println("Summe= ",sum(r))
QoE_1080=(-3.035*r[1]^(-0.5061)+1.022)*5
QoE_720=(-4.85*r[2]^(-0.647)+1.011)*5
QoE_360=(-17.53*r[3]^(-1.048)+0.9912)*5
println("QoE_1080 =", QoE_1080)
println("QoE_720 =", QoE_720)
println("QoE_360 =", QoE_360)
trace_qoe[i,1]=QoE_1080
trace_qoe[i,2]=QoE_720
trace_qoe[i,3]=QoE_360
end
plot(bw,trace_r,fontfamily="Arial",legend=:top,tickfontsizes=10,legendfont=(12,"Arial"),guidefontsize=12,xaxis="Gesamtrate kbit/s",dpi=600,color=:black, linestyle=[:solid :dash :dashdot],yaxis="MOS Fair Rate für Display",label=["r_1080p" "r_720p" "r_360p"])
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_9")
