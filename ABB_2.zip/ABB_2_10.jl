println("Abb. 2.10 Erforderliche Gesamtrate r für faire QoE-Werte")
using NLsolve
using Plots
# 6 Werte für Rate festlegen
iter=6
trace_r=rand(iter,3)
trace_qoe=rand(iter,3)
qoe_soll=rand(iter)
bw=rand(iter)
# in diesem Fall: jeweils 1 Endsystem/Display n1=n2=n3=1
n1=1
n2=1
n3=1
for i=1:iter
R=500*i
bw[i]=R
function f!(F,x)
    F[1] = (-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)-2*(-17.53*x[3]^-1.048+0.9912)
    F[2]=-2*(-3.03*x[1]^-0.50+1.02)+(-4.85*x[2]^-0.64+1.01)+(-17.53*x[3]^-1.048+0.9912)
    F[3] = R-n1*x[1]-n2*x[2]-n3*x[3]
end
y=nlsolve(f!,[ 505.1; 500.2;160.1], autodiff = :forward)
println("   ")
# Ergebnisausgabe
println("ERGEBNIS = ",y.zero)
# Porbe
r=y.zero
trace_r[i,:]=r
println("Summe= ",sum(r))
QoE_1080=(-3.035*r[1]^(-0.5061)+1.022)*5
QoE_720=(-4.85*r[2]^(-0.647)+1.011)*5
QoE_360=(-17.53*r[3]^(-1.048)+0.9912)*5
println("QoE_1080 =", QoE_1080)
println("QoE_720 =", QoE_720)
println("QoE_360 =", QoE_360)
trace_qoe[i,1]=QoE_1080
trace_qoe[i,2]=QoE_720
trace_qoe[i,3]=QoE_360
qoe_soll[i]=4.5
end
# Diagramm der MOS-Werte
plot(bw,trace_qoe,legend=:right,fontfamily="Arial",tickfontsizes=10,legendfont=(12,"Arial"),guidefontsize=12,xaxis="Gesamtrate kbit/s",dpi=600,color=:black, linestyle=[:solid :dash :dashdot],yaxis="Fair MOS für Display",label=["1080p" "720p" "360p"])
# Soll-Linie 4.5 in Diagramm eintragen
plot!(bw[1:4],qoe_soll[1:4],color=:black,linewidth=1,linestyle=:dot,label="qoe_soll")
png("D:/BUCH/Github_Zip/KAP_2/ABB_2_10")
